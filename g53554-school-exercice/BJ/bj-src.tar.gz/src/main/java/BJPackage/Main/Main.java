package BJPackage.Main;

    import BJPackage.Controller.Controller;

public class Main {
    public static void main(String[] args) {
        Controller controller = new Controller();
        controller.play();
    }


}
