package BJPackage.Model;

public enum State {
    WIN,FAIL,NEUTRE;
}
